var allTableCells = document.getElementsByTagName("td");

for (var i = 0, max = allTableCells.length; i < max; i++) {
  var node = allTableCells[i];

  // Get the title property from the cell
  var title = node.getAttribute("title");
  var currentText = title;

  // Convert to number
  currentText = Number(currentText);

  // Remap currentText from [log(0), log(1)] to [0, 255]
  currentText = Math.round((255 * currentText) / 0.1);

  // Color on a spectrum from red to green based on the value
  var color = "rgb(" + (255 - currentText) + "," + currentText + ",0)";

  // Set the background color of the cell
  node.style.backgroundColor = color;
}

document.addEventListener("DOMContentLoaded", function () {
  // Get all td elements
  const tableCells = document.getElementsByTagName("td");

  for (let cell of tableCells) {
    // Add event listener for mouseenter
    cell.addEventListener("mouseenter", function () {
      cell.classList.add("expanded-cell");
    });

    // Add event listener for mouseleave
    cell.addEventListener("mouseleave", function () {
      cell.classList.remove("expanded-cell");
    });
  }
});
